const $ = (selector) => document.querySelector(selector);

let allCategories = [];
let selectedCategoryId = null;
let currentUsername = localStorage.getItem("uranomc_username") || "";

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[char]));
}

async function api(url, options) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Error de API");
  return data;
}

function copyServerIp() {
  navigator.clipboard?.writeText("uranomc.lol");
  const label = $(".server-info.left b");
  if (!label) return;
  const original = label.textContent;
  label.textContent = "¡COPIADO!";
  setTimeout(() => label.textContent = original, 1200);
}

document.querySelector(".server-info.left")?.addEventListener("click", copyServerIp);

function getParentId(category) {
  const value = category.parent_id ?? category.parentId ?? category.parent_category_id ?? category.parentCategoryId;
  if (value !== undefined && value !== null && value !== "") return String(value);

  const parent = category.parent_category ?? category.parentCategory ?? category.parent;
  if (parent && typeof parent === "object") {
    return String(parent.id ?? parent.category_id ?? "");
  }
  if (typeof parent === "string" || typeof parent === "number") return String(parent);
  return null;
}

function buildCategoryTree(categories) {
  const map = new Map(categories.map(c => [String(c.id), { ...c, children: [] }]));
  const roots = [];

  for (const category of map.values()) {
    const parentId = getParentId(category);
    if (parentId && map.has(parentId) && parentId !== String(category.id)) {
      map.get(parentId).children.push(category);
    } else {
      roots.push(category);
    }
  }
  return roots;
}

function renderCategories() {
  const list = $("#categoryList");
  const roots = buildCategoryTree(allCategories);

  if (!roots.length) {
    list.innerHTML = `<div class="category-empty">No hay categorías configuradas.</div>`;
    return;
  }

  list.innerHTML = roots.map(root => renderCategoryNode(root, 0)).join("");

  list.querySelectorAll(".category-parent-toggle").forEach(button => {
    button.addEventListener("click", () => {
      const item = button.closest(".category-group");
      const isOpen = item.classList.toggle("open");
      button.setAttribute("aria-expanded", String(isOpen));
    });
  });

  list.querySelectorAll(".category-leaf, .category-parent-link").forEach(button => {
    button.addEventListener("click", async () => {
      list.querySelectorAll(".category-item").forEach(x => x.classList.remove("active"));
      button.classList.add("active");
      await selectCategory(button.dataset.category);
    });
  });
}

function renderCategoryNode(category, level) {
  const hasChildren = category.children?.length > 0;
  const id = escapeHtml(category.id);
  const name = escapeHtml(category.name);

  if (!hasChildren) {
    return `
      <button class="category-item category-leaf" data-category="${id}">
        <span class="category-icon">${level ? "›" : "•"}</span>
        <span>${name}</span>
      </button>
    `;
  }

  return `
    <div class="category-group">
      <div class="category-parent-row">
        <button class="category-parent-link category-item" data-category="${id}">
          <span class="category-icon">▸</span>
          <span>${name}</span>
        </button>
        <button class="category-parent-toggle" aria-label="Mostrar subcategorías" aria-expanded="false">⌄</button>
      </div>
      <div class="category-children">
        ${category.children.map(child => renderCategoryNode(child, level + 1)).join("")}
      </div>
    </div>
  `;
}

function categorySlug(category) {
  return String(category?.slug || category?.name || category?.id || "categoria")
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "") || String(category?.id || "categoria");
}

function setCategoryUrl(category) {
  const slug = categorySlug(category);
  history.pushState({ category: String(category.id) }, "", `/categoria/${encodeURIComponent(slug)}`);
}

function setHomeUrl() {
  if (location.pathname !== "/") history.pushState({}, "", "/");
}

function showHomeView(pushUrl = true) {
  if (pushUrl) setHomeUrl();
  selectedCategoryId = null;
  $("#homeView").hidden = false;
  $("#categoryView").hidden = true;
  $("#homeLink")?.classList.add("active");
  document.querySelectorAll(".category-item").forEach(x => x.classList.remove("active"));
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function showCategoryView(category) {
  $("#homeView").hidden = true;
  $("#categoryView").hidden = false;
  $("#homeLink")?.classList.remove("active");
  document.querySelectorAll(".category-item").forEach(x => {
    x.classList.toggle("active", x.dataset.category === String(category.id));
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
}

async function loadCategories() {
  const list = $("#categoryList");
  list.innerHTML = `<div class="category-loading">Cargando categorías...</div>`;

  try {
    const response = await api("/api/categories");
    allCategories = response.data || [];
    renderCategories();
    await handleRoute();
  } catch (error) {
    console.error(error);
    list.innerHTML = `<div class="category-empty">No se pudieron cargar las categorías de Tebex.</div>`;
    showHomeView(false);
  }
}

function renderCatalogHome(error = false) {
  const title = $("#catalogTitle");
  const subtitle = $("#catalogSubtitle");
  const grid = $("#packagesGrid");

  title.textContent = "CATEGORÍAS DE LA TIENDA";
  subtitle.textContent = error
    ? "Revisa tus claves de Tebex y vuelve a cargar la página."
    : "Selecciona una categoría para ver sus paquetes disponibles.";
  grid.innerHTML = `
    <div class="catalog-placeholder">
      <div class="catalog-placeholder-icon">🛒</div>
      <b>ELIGE UNA CATEGORÍA</b>
      <span>Abre una categoría desde el menú de la izquierda para ver los paquetes.</span>
    </div>
  `;
}

async function selectCategory(categoryId, updateUrl = true) {
  selectedCategoryId = String(categoryId);
  const category = allCategories.find(c => String(c.id) === selectedCategoryId);
  if (!category) return showHomeView(false);

  if (updateUrl) setCategoryUrl(category);
  showCategoryView(category);

  const title = $("#categoryPageTitle");
  const subtitle = $("#categoryPageSubtitle");
  const grid = $("#categoryPackagesGrid");

  title.textContent = String(category.name || "CATEGORÍA").toUpperCase();
  subtitle.textContent = "Cargando paquetes...";
  grid.innerHTML = `<div class="catalog-placeholder"><div class="spinner"></div><span>Cargando productos de Tebex...</span></div>`;

  try {
    const response = await api(`/api/categories/${encodeURIComponent(categoryId)}`);
    const raw = response.data || response;
    const data = Array.isArray(raw) ? (raw[0] || {}) : raw;
    const packages = data.packages || [];
    subtitle.textContent = packages.length
      ? `${packages.length} paquete${packages.length === 1 ? "" : "s"} disponible${packages.length === 1 ? "" : "s"}.`
      : "Esta categoría todavía no tiene paquetes disponibles.";
    renderPackages(packages, "#categoryPackagesGrid");
  } catch (error) {
    console.error(error);
    const fallback = category?.packages || [];
    renderPackages(fallback, "#categoryPackagesGrid");
    subtitle.textContent = fallback.length
      ? "Paquetes disponibles."
      : "No se pudieron cargar los paquetes de esta categoría.";
  }
}

async function handleRoute() {
  const match = location.pathname.match(/^\/categoria\/(.+)$/);
  if (!match) {
    renderCatalogHome();
    showHomeView(false);
    return;
  }

  const routeValue = decodeURIComponent(match[1]).toLowerCase();
  const category = allCategories.find(c =>
    String(c.id).toLowerCase() === routeValue ||
    categorySlug(c).toLowerCase() === routeValue ||
    String(c.slug || "").toLowerCase() === routeValue
  );

  if (category) {
    await selectCategory(category.id, false);
  } else {
    showHomeView(false);
  }
}

function packageData(pkg) {
  const image = pkg.image || pkg.image_url || pkg.media?.[0]?.url || pkg.media?.[0]?.image || "";
  const price = pkg.total_price ?? pkg.base_price ?? pkg.price ?? 0;
  const currency = typeof pkg.currency === "object"
    ? (pkg.currency?.iso_4217 || pkg.currency?.symbol || "")
    : (pkg.currency || "USD");
  return {
    id: Number(pkg.id),
    name: String(pkg.name || "Paquete"),
    image,
    price: String(price),
    currency: String(currency),
    descriptionHtml: String(pkg.description || "")
  };
}

function renderPackages(packages, target = "#packagesGrid") {
  const grid = $(target);
  if (!grid) return;
  if (!packages.length) {
    grid.innerHTML = `<div class="catalog-placeholder"><div class="catalog-placeholder-icon">📦</div><b>SIN PAQUETES</b><span>Esta categoría no tiene productos disponibles.</span></div>`;
    return;
  }

  grid.innerHTML = packages.map(pkg => {
    const item = packageData(pkg);
    return `
      <article class="package">
        <div class="package-image-box">
          ${item.image
            ? `<img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.name)}" loading="lazy">`
            : `<div class="package-image-placeholder">URANO<br><span>MC</span></div>`}
        </div>
        <div class="package-body">
          <h4 title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</h4>
          <div class="package-price">${escapeHtml(item.price)} ${escapeHtml(item.currency)}</div>
          <div class="package-footer">
            <div class="package-actions">
              <button class="info-btn" type="button" title="Más información" aria-label="Más información de ${escapeHtml(item.name)}"
                data-package="${escapeHtml(JSON.stringify(item).replace(/"/g, "&quot;"))}">i</button>
              <button class="buy" type="button" data-buy-package="${item.id}">COMPRAR</button>
            </div>
          </div>
        </div>
      </article>
    `;
  }).join("");

  grid.querySelectorAll("[data-buy-package]").forEach(button => {
    button.addEventListener("click", () => openPurchaseModal(Number(button.dataset.buyPackage)));
  });

  grid.querySelectorAll(".info-btn").forEach(button => {
    button.addEventListener("click", () => {
      try {
        const item = JSON.parse(button.dataset.package.replace(/&quot;/g, '"'));
        openPackageInfo(item);
      } catch (error) {
        console.error("No se pudo abrir la información del paquete:", error);
      }
    });
  });
}

let currentInfoPackage = null;

function openPackageInfo(item) {
  currentInfoPackage = item;
  const image = $("#packageInfoImage");
  const title = $("#packageInfoTitle");
  const price = $("#packageInfoPrice");
  const description = $("#packageInfoDescription");
  const buyButton = $("#packageInfoBuy");

  title.textContent = item.name;
  price.textContent = `${item.price} ${item.currency}`;
  if (buyButton) buyButton.disabled = false;
  const placeholder = document.querySelector(".package-info-image-placeholder");
  image.src = item.image || "";
  image.alt = item.name;
  image.hidden = !item.image;
  if (placeholder) placeholder.hidden = Boolean(item.image);

  if (!item.image) {
    image.removeAttribute("src");
  }

  // La descripción viene de Tebex en HTML. Se inserta en un contenedor
  // aislado después de retirar elementos potencialmente peligrosos.
  const cleanHtml = item.descriptionHtml
    .replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?>[\s\S]*?<\/style>/gi, "")
    .replace(/\son\w+\s*=\s*(['"]).*?\1/gi, "")
    .replace(/javascript:/gi, "");
  description.innerHTML = cleanHtml || "<p>Este paquete no tiene una descripción adicional.</p>";

  if (description) description.scrollTop = 0;
  $("#packageInfoModal")?.classList.add("show");
  document.body.classList.add("modal-open");
}

$("#packageInfoBuy")?.addEventListener("click", () => {
  if (!currentInfoPackage?.id) return;
  closePackageInfo();
  openPurchaseModal(currentInfoPackage.id);
});

function closePackageInfo() {
  $("#packageInfoModal")?.classList.remove("show");
  document.body.classList.remove("modal-open");
}

function openLoginModal(forPackageId = null) {
  $("#loginModal")?.classList.add("show");
  document.body.classList.add("modal-open");
  const input = $("#minecraftUsername");
  if (input) {
    input.value = currentUsername;
    setTimeout(() => input.focus(), 80);
  }
  $("#purchasePackageId").value = forPackageId ? String(forPackageId) : "";
}

function closeLoginModal() {
  $("#loginModal")?.classList.remove("show");
  document.body.classList.remove("modal-open");
}

function updateMinecraftAvatar(username = currentUsername) {
  const avatars = [$("#loginAvatar"), $("#loginModalAvatar")].filter(Boolean);
  avatars.forEach((avatar) => {
    if (!username) {
      avatar.removeAttribute("src");
      avatar.classList.remove("has-skin");
      if (avatar.tagName === "IMG") avatar.alt = "Avatar de Minecraft";
      return;
    }
    avatar.src = `https://mc-heads.net/avatar/${encodeURIComponent(username)}/64`;
    avatar.alt = `Skin de ${username}`;
    avatar.classList.add("has-skin");
    avatar.onerror = () => {
      avatar.removeAttribute("src");
      avatar.classList.remove("has-skin");
    };
  });
}

function saveUsername() {
  const input = $("#minecraftUsername");
  const username = input.value.trim();
  if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) {
    $("#loginError").textContent = "Ingresa un nombre de Minecraft válido (3 a 16 caracteres).";
    input.focus();
    return;
  }

  currentUsername = username;
  localStorage.setItem("uranomc_username", username);
  updateLoginUI();

  const packageId = $("#purchasePackageId").value;
  closeLoginModal();
  if (packageId) createCheckout(Number(packageId));
}

function updateLoginUI() {
  const name = $("#loggedName");
  const status = $("#loginStatus");
  if (name) name.textContent = currentUsername || "Invitado";
  if (status) status.textContent = currentUsername ? "CUENTA DE MINECRAFT" : "HAZ CLIC PARA INGRESAR";
  updateMinecraftAvatar();
}

function openPurchaseModal(packageId) {
  if (currentUsername) {
    createCheckout(packageId);
    return;
  }
  openLoginModal(packageId);
}

async function createCheckout(packageId) {
  if (!currentUsername) {
    openLoginModal(packageId);
    return;
  }

  const buyButtons = document.querySelectorAll(`[data-buy-package="${packageId}"]`);
  buyButtons.forEach(button => {
    button.disabled = true;
    button.dataset.originalText = button.textContent;
    button.textContent = "CREANDO...";
  });

  try {
    const result = await api("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ packageId, username: currentUsername })
    });

    if (!result?.url) {
      throw new Error("Tebex no devolvió un checkout válido.");
    }

    // Tebex devuelve el checkout ya preparado para ese paquete y jugador.
    window.location.assign(result.url);
  } catch (error) {
    console.error("Checkout Tebex:", error);
    alert(error.message || "No se pudo crear el checkout de Tebex.");
  } finally {
    buyButtons.forEach(button => {
      button.disabled = false;
      button.textContent = button.dataset.originalText || "COMPRAR";
    });
  }
}

async function loadPayments() {
  try {
    const response = await api("/api/payments?limit=8");
    const payments = Array.isArray(response) ? response : (response.data || []);

    if (!payments.length) {
      $("#recentPayments").textContent = "No hay pagos recientes";
      $("#topDonor").innerHTML = `<div class="skin">◈</div><div><b>Sin pagos</b><small>Quién más ha gastado este mes.</small></div>`;
      return;
    }

    $("#recentPayments").innerHTML = payments.slice(0, 5).map(payment => `
      <div class="payment-row">
        <span>${escapeHtml(payment.player?.name || "Jugador")}</span>
        <b>${escapeHtml(String(payment.amount ?? ""))} ${escapeHtml(payment.currency?.iso_4217 || "")}</b>
      </div>
    `).join("");

    const totals = new Map();
    for (const payment of payments) {
      const name = payment.player?.name || "Jugador";
      const amount = Number(payment.amount || 0);
      totals.set(name, (totals.get(name) || 0) + amount);
    }
    const top = [...totals.entries()].sort((a, b) => b[1] - a[1])[0];
    $("#topDonor").innerHTML = `
      <div class="skin">◈</div>
      <div><b>${escapeHtml(top?.[0] || "Sin pagos")}</b><small>Quién más ha gastado este mes.</small></div>
    `;
  } catch (error) {
    $("#recentPayments").textContent = "No se pudieron cargar los pagos.";
    $("#topDonor").innerHTML = `<div class="skin">?</div><div><b>Sin datos</b><small>Configura la Game Server Secret.</small></div>`;
  }
}

async function verifyGiftcard() {
  const code = $("#giftCode").value.trim();
  if (!code) return;

  $("#giftResult").textContent = "Verificando...";
  try {
    const response = await api(`/api/giftcards/${encodeURIComponent(code)}`);
    const card = response?.data || response;
    $("#giftResult").textContent =
      `Saldo: ${card.balance?.remaining ?? "?"} ${card.balance?.currency ?? ""}` +
      (card.void ? " · ANULADA" : "");
  } catch (error) {
    $("#giftResult").textContent = "Giftcard no encontrada o no válida.";
  }
}

async function loadStoreInfo() {
  try {
    const response = await api("/api/store");
    const store = response.store || {};
    if (store.name) document.title = `${store.name} · Tienda`;
  } catch (error) {
    console.warn("Información de tienda no disponible:", error.message);
  }
}

function makeStars() {
  const container = $("#stars");
  for (let i = 0; i < 85; i++) {
    const star = document.createElement("i");
    star.className = "star";
    star.style.left = `${Math.random() * 100}%`;
    star.style.top = `${Math.random() * 100}%`;
    star.style.opacity = `${0.25 + Math.random() * 0.75}`;
    container.appendChild(star);
  }
}

$("#loginButton")?.addEventListener("click", () => openLoginModal());
$("#homeLink")?.addEventListener("click", () => showHomeView(true));
$("#backHome")?.addEventListener("click", () => showHomeView(true));
window.addEventListener("popstate", () => handleRoute());
$("#loginClose")?.addEventListener("click", closeLoginModal);
$("#loginCancel")?.addEventListener("click", closeLoginModal);
$("#loginSave")?.addEventListener("click", saveUsername);
$("#minecraftUsername")?.addEventListener("keydown", (event) => {
  if (event.key === "Enter") saveUsername();
});
$("#loginModal")?.addEventListener("click", (event) => {
  if (event.target.id === "loginModal") closeLoginModal();
});
$("#packageInfoClose")?.addEventListener("click", closePackageInfo);
$("#packageInfoModal")?.addEventListener("click", (event) => {
  if (event.target.id === "packageInfoModal") closePackageInfo();
});

updateLoginUI();
makeStars();
loadStoreInfo();
loadCategories();
loadPayments();
finishTebexAuth();
