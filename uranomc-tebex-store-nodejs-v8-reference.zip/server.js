require("dotenv").config();

const crypto = require("crypto");
const express = require("express");
const helmet = require("helmet");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);

const required = [
  "TEBEX_PROJECT_ID",
  "TEBEX_PUBLIC_KEY",
  "TEBEX_PRIVATE_KEY",
  "TEBEX_WEBHOOK_SECRET",
  "TEBEX_GAME_SERVER_SECRET"
];

function tebexBasicAuth() {
  const token = Buffer
    .from(`${process.env.TEBEX_PROJECT_ID}:${process.env.TEBEX_PRIVATE_KEY}`)
    .toString("base64");
  return `Basic ${token}`;
}

async function tebexFetch(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      ...(options.headers || {})
    }
  });

  const text = await response.text();
  let data;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = { raw: text };
  }

  if (!response.ok) {
    const error = new Error(`Tebex API ${response.status}`);
    error.status = response.status;
    error.data = data;
    throw error;
  }

  return data;
}

async function headless(pathname, options = {}) {
  const token = encodeURIComponent(process.env.TEBEX_PUBLIC_KEY);
  return tebexFetch(`https://headless.tebex.io/api/accounts/${token}${pathname}`, options);
}

async function plugin(pathname, options = {}) {
  return tebexFetch(`https://plugin.tebex.io${pathname}`, {
    ...options,
    headers: {
      ...(options.headers || {}),
      "X-Tebex-Secret": process.env.TEBEX_GAME_SERVER_SECRET
    }
  });
}

async function checkout(pathname, options = {}) {
  return tebexFetch(`https://checkout.tebex.io/api${pathname}`, {
    ...options,
    headers: {
      ...(options.headers || {}),
      "Authorization": tebexBasicAuth()
    }
  });
}

/*
 * Webhook: raw body is required because Tebex signs the exact JSON body.
 * Signature algorithm:
 * SHA256(HMAC-SHA256(SHA256(rawBody), webhookSecret))
 * More precisely, Tebex documents HMAC-SHA256 using the SHA256 body hash as
 * the HMAC message.
 */
app.post(
  "/api/tebex/webhook",
  express.raw({ type: "application/json", limit: "2mb" }),
  (req, res) => {
    try {
      const signature = req.get("X-Signature");
      if (!signature) return res.status(401).json({ error: "Missing X-Signature" });

      const body = req.body.toString("utf8");
      const bodyHash = crypto.createHash("sha256").update(body, "utf8").digest("hex");
      const expected = crypto
        .createHmac("sha256", process.env.TEBEX_WEBHOOK_SECRET)
        .update(bodyHash)
        .digest("hex");

      const a = Buffer.from(signature, "utf8");
      const b = Buffer.from(expected, "utf8");
      if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
        return res.status(401).json({ error: "Invalid signature" });
      }

      const event = JSON.parse(body);

      // Validation webhook: Tebex expects the webhook id back.
      if (event.type === "validation.webhook") {
        return res.status(200).json({ id: event.id });
      }

      console.log(`[TEBEX WEBHOOK] ${event.type || "unknown"} - ${event.id || "no-id"}`);

      // Aquí puedes conectar tu lógica propia:
      // - payment.completed
      // - payment.refunded
      // - recurring-payment.*
      // etc.
      return res.sendStatus(204);
    } catch (error) {
      console.error("Webhook error:", error);
      return res.status(400).json({ error: "Invalid webhook body" });
    }
  }
);

app.use(helmet({
  contentSecurityPolicy: false
}));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    configured: required.reduce((acc, key) => {
      acc[key] = Boolean(process.env[key]);
      return acc;
    }, {})
  });
});

app.get("/api/store", async (req, res) => {
  try {
    const [info, store] = await Promise.all([
      plugin("/information"),
      headless("")
    ]);

    res.json({
      plugin: info,
      store: store?.data || store
    });
  } catch (error) {
    res.status(error.status || 500).json({
      error: "No se pudo obtener la información de Tebex.",
      detail: error.data || error.message
    });
  }
});

app.get("/api/categories", async (req, res) => {
  try {
    const data = await headless("/categories?includePackages=1");
    res.json(data);
  } catch (error) {
    res.status(error.status || 500).json({
      error: "No se pudieron cargar las categorías.",
      detail: error.data || error.message
    });
  }
});

app.get("/api/categories/:id", async (req, res) => {
  try {
    const id = encodeURIComponent(req.params.id);
    const data = await headless(`/categories/${id}?includePackages=1`);
    res.json(data);
  } catch (error) {
    res.status(error.status || 500).json({
      error: "No se pudo cargar la categoría.",
      detail: error.data || error.message
    });
  }
});

app.get("/api/packages", async (req, res) => {
  try {
    const data = await headless("/packages");
    res.json(data);
  } catch (error) {
    res.status(error.status || 500).json({
      error: "No se pudieron cargar los paquetes.",
      detail: error.data || error.message
    });
  }
});

app.get("/api/payments", async (req, res) => {
  try {
    const limit = Math.min(Math.max(Number(req.query.limit || 10), 1), 100);
    const data = await plugin(`/payments?limit=${limit}`);
    res.json(data);
  } catch (error) {
    res.status(error.status || 500).json({
      error: "No se pudieron cargar los pagos recientes.",
      detail: error.data || error.message
    });
  }
});

app.get("/api/giftcards/:code", async (req, res) => {
  try {
    const code = encodeURIComponent(String(req.params.code).trim());
    if (!code) return res.status(400).json({ error: "Código vacío." });

    const data = await plugin(`/gift-cards/lookup/${code}`);
    res.json(data);
  } catch (error) {
    res.status(error.status || 500).json({
      error: "No se encontró la giftcard o Tebex rechazó la consulta.",
      detail: error.data || error.message
    });
  }
});

async function createHeadlessBasket(username, packageId) {
  const baseUrl = String(process.env.STORE_PUBLIC_URL || "").replace(/\/$/, "");
  const returnUrl = baseUrl ? `${baseUrl}/` : "/";
  const custom = {
    minecraft_username: String(username),
    source: "uranomc-custom-store"
  };

  const basketResponse = await headless("/baskets", {
    method: "POST",
    body: JSON.stringify({
      complete_url: `${returnUrl}?checkout=complete`,
      cancel_url: `${returnUrl}?checkout=cancel`,
      complete_auto_redirect: false,
      custom
    })
  });

  const basket = basketResponse?.data || basketResponse;
  if (!basket?.ident) throw new Error("Tebex no devolvió un identificador de cesta.");

  const addedResponse = await headless(`/baskets/${encodeURIComponent(basket.ident)}/packages`, {
    method: "POST",
    body: JSON.stringify({
      package_id: String(packageId),
      quantity: 1
    })
  });

  return addedResponse?.data || addedResponse;
}

app.post("/api/checkout", async (req, res) => {
  try {
    const { packageId, username } = req.body || {};
    const cleanUsername = String(username || "").trim();

    if (!packageId || !/^[A-Za-z0-9_]{3,16}$/.test(cleanUsername)) {
      return res.status(400).json({
        error: "packageId y un nombre de Minecraft válido son obligatorios."
      });
    }

    // Para una compra directa de un jugador, Tebex ofrece un endpoint de
    // Plugin API que crea el checkout y ya asocia el nombre de Minecraft.
    // Esto evita depender de una segunda autenticación de Headless.
    const result = await plugin("/checkout", {
      method: "POST",
      body: JSON.stringify({
        package_id: String(packageId),
        username: cleanUsername
      })
    });

    if (!result?.url) {
      return res.status(502).json({
        error: "Tebex no devolvió una URL de checkout válida.",
        detail: result || null
      });
    }

    res.status(200).json({
      url: result.url,
      expires: result.expires || null,
      username: cleanUsername
    });
  } catch (error) {
    console.error("Checkout error:", error);
    res.status(error.status || 500).json({
      error: "No se pudo crear el checkout de Tebex.",
      detail: error.data || error.message
    });
  }
});


app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Uranomc Store ejecutándose en http://localhost:${PORT}`);
});
