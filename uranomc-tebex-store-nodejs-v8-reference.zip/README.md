# Uranomc Store + Tebex

Proyecto Node.js/Express preparado para reproducir el diseño mostrado en las capturas y conectar el frontend con Tebex sin exponer las claves privadas al navegador.

## 1. Instalar

```bash
npm install
```

## 2. Configurar claves

Copia `.env.example` como `.env` y completa:

- `TEBEX_PROJECT_ID`
- `TEBEX_PUBLIC_KEY` — Public Key / Public Token de tu tienda para Headless API.
- `TEBEX_PRIVATE_KEY`
- `TEBEX_WEBHOOK_SECRET`
- `TEBEX_GAME_SERVER_SECRET`

La Public Key se utiliza para consultar el catálogo mediante Headless API. El Project ID + Private Key son las credenciales del Checkout API; la Private Key debe mantenerse únicamente en el servidor.
La Game Server Secret se usa para los endpoints del Plugin/Game Server API.
La Webhook Secret se usa para verificar `X-Signature`.

## 3. Ejecutar

```bash
npm start
```

Abre:

```text
http://localhost:3000
```

## Qué incluye

- Diseño oscuro estilo Uranomc basado en las capturas proporcionadas.
- Categorías y paquetes cargados desde Tebex Headless API.
- Botón de compra para Minecraft que envía `package_id` + `username` al checkout de Tebex y redirige al jugador.
- Información del servidor mediante Game Server API.
- Pagos recientes mediante Game Server API.
- Top donador calculado a partir de pagos recientes.
- Verificación de giftcard mediante Game Server API.
- Webhook `POST /api/tebex/webhook` con verificación HMAC SHA-256 usando el método documentado por Tebex.
- Las claves privadas nunca se envían al frontend.

## Webhook

Configura en Tebex el endpoint:

```text
https://TU-DOMINIO/api/tebex/webhook
```

Para desarrollo local necesitarás exponer temporalmente el servidor mediante un túnel HTTPS.

## Importante

No pegues tus claves de Tebex dentro de `public/app.js` ni `public/index.html`.
Si una Private Key se filtra, rótala desde el panel de Tebex.


### ¿Para qué sirve la Public Key?

La **Public Key** (también llamada Public Token en algunas partes del ecosistema Tebex) identifica tu webstore para la **Headless API** y permite consultar el catálogo público, como categorías y paquetes. No sustituye a la Private Key.

En este proyecto solo debes colocarla en:

```env
TEBEX_PUBLIC_KEY=TU_PUBLIC_KEY
```

No necesitas ponerla en `public/app.js`.


## Checkout y login de Minecraft

El botón **COMPRAR** utiliza el flujo de cestas de la Headless API de Tebex: crea una cesta, agrega el paquete y redirige a `links.checkout`. Esto evita el endpoint `/plugin.tebex.io/checkout` que no corresponde al flujo de Checkout de una tienda Headless. Tebex documenta este flujo con `POST /baskets`, `POST /baskets/{ident}/packages` y la URL `links.checkout`. 

La primera compra puede llevar al jugador al enlace de autenticación de Tebex para asociar la cesta con su cuenta de Minecraft. Al volver a la tienda, la cesta se finaliza automáticamente; el nick que se ingresó en la tienda queda guardado en el navegador para que no vuelva a aparecer el modal de login al comprar otro paquete.

El botón **i** de cada paquete abre una ficha con la imagen, precio y descripción proporcionados por Tebex.

La cabeza del jugador se carga automáticamente usando su nombre de Minecraft y se muestra tanto en el encabezado como en el modal de login.
